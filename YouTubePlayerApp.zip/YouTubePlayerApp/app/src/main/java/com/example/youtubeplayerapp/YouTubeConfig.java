package com.example.youtubeplayerapp;

public class YouTubeConfig {
    public YouTubeConfig() {
    }
    private static final String API_KEY = "AIzaSyCyiMlUpYyPj7Wrh3QLyblB1tPOpkFD000";

    public static String getApiKey() {
        return API_KEY;
    }
}
